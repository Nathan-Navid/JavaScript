function logout(element){
    console.log(element.innerText);
    element.innerText ="Logout"
}
function hide(element) {
    element.remove();
    
}
function popUp(){
    var popup = document.getElementById(`#popup`)
}
