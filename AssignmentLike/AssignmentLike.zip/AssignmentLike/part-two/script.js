function increment(element){
    var el = document.querySelector(`#${element}`)
    el.innerText++
}